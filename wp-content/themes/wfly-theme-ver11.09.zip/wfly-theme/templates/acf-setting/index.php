<?php

// Silence is golden.

?>
